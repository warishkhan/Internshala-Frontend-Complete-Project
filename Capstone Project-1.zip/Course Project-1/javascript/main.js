//Hamburger Script

let hamburger = document.querySelector(".toggler")
hamburger.onclick = function (){
  let navBar = document.querySelector(".navbar")
  navBar.classList.toggle("active-nav")
}


// Function to fetch and inject HTML content
const injectHTML = async (elementId, filePath) => {
    try {
        const response = await fetch(filePath);
        if (!response.ok) {
            throw new Error(`Failed to fetch: ${filePath}`);
        }
        const html = await response.text();
        document.getElementById(elementId).innerHTML = html;
    } catch (error) {
        console.error(error.message);
    }
};

// Inject header and footer into respective elements
window.onload = () => {
    injectHTML('header-container', 'header.html');
    injectHTML('navbar-container', 'navbar.html');
    injectHTML('footer-container', 'footer.html');
};


// login
let login = document.querySelector("#login")
login.onclick = function(){
let email = document.querySelector("#input1").value;
let password = parseInt(document.querySelector("#input2").value);
if(!email && !password){
    alert("please fill all the field")
}else if(email === "admin@admin.com" && Number(password) === 123456  ){
    alert("Login Successfull")
}else{
    alert("Incorrect email or password")
}
}