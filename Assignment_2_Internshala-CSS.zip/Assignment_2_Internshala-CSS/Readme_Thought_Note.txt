                                             ******* Summery of my project *******

                                             batch :- 1st November 2023

Name :- Warish khan

Assignment :- Assignment-2-Internshala-CSS

I created this Restaurant website using Html and css only. This website based on focus only Css and its properties. This website will help people to get delicious and healthy food on time without getting delayed when you order your meal online. It has variety of foods available in this Restaurent.How I created this website I mention it in code of this website using html and css comments.

********* Tags ,Attributes and CSS properties  used in the website **********

Now I am again going to explain what attributes, tags and css properties i used in the website. 
here are the names of tags, attributes and css properties used in the website given below:

I used <a> anchor tag to create routes or hyperlink between one page to another webpage.
The <link> tag defines the relationship between the current document and an external resource.
The <div> tag defines a division or a section in an HTML document. The <div> tag is used as a container for HTML elements - which is then styled with CSS or manipulated with JavaScript.
The <img> tag is used to embed an image in an HTML page.
Universal Selector in CSS is used to select all the elements on the HTML page.
The box-sizing property allows us to include the padding and border in an element's total width and height
The CSS position property defines the position of an element in a document. This property works with the left, right, top, bottom and z-index properties to determine the final position of an element on a page. There are five values the position property can take.
The :hover selector is used to select elements when you mouse over them.
Google Fonts
The CSS :root pseudo-class selector is used to select the highest-level parent of a given specification.
CSS grid layout introduces a two-dimensional grid system to CSS. Grids can be used to lay out major page areas or small user interface elements.
CSS gradients let you display smooth transitions between two or more specified colors.
The Flexible Box Layout Module, makes it easier to design flexible responsive layout structure without using float or positioning.
CSS transitions allows you to change property values smoothly, over a given duration.
grouping selector.
The <form> tag is used to create an HTML form for user input.
The <input> tag specifies an input field where the user can enter data.
The HTML type Attribute is used to specify the type of input for <input> elements.
If you only want to style a specific input type, you can use attribute selectors: input[type=text] - will only select text fields