               ******* Summery of my project *******

batch :- 1st November 2023

Name :- Warish khan

I created this Tourism website using Html and css. i used little bit of css in this website. This website will help to people know about dhanbad.How I created this website I mention it in code of this website using html comments.

********* Tags and Attributes used in the website **********

Now I am again going to explain what attributes or tags i used in the website. 
here are the names of tags or attributes used in the website given below:

I used <a> anchor tag to create routes or hyperlink between one page to another webpage.
The <h1> to <h6> tags are used to define HTML headings.
The <i> tag is used to make your text itallic.
<b> tag is used to make your text bold
<p> tag is used to define paragarph of the webpage
u tag is used to create underline below your text.
The <br> tag inserts a single line break.
The <table> tag defines an HTML table.
The <thead> tag is used to group header content in an HTML table.
The <tr> tag defines a row in an HTML table.
The <td> tag defines a standard data cell in an HTML table.
The <img> tag is used to embed an image in an HTML page.
The src attribute specifies the location (URL) of the external resource.
The style attribute specifies an inline style for an element.
If you want to embed external content like video or audio on your website, inline frames have proven extremely useful for that. The tags provide a simple and elegant solution to accommodate external content in a HTML document.
The <form> tag is used to create an HTML form for user input.
The <input> tag specifies an input field where the user can enter data.
The HTML type Attribute is used to specify the type of input for <input> elements.
The <style> tag is used to define style information (CSS) for a document.
 The <sup> tag is used to add a superscript text to the HTML document. The <sup> tag defines the superscript text. Superscript text appears half a character above the normal line and is sometimes rendered in a smaller font