function resetAnswer() {
    // Reset the result when any input changes
    document.getElementById('result').value = '';
}

function calculate() {
    // Get values from inputs

    // The parseFloat function converts its first argument to a string, parses that string as a decimal number literal, then returns a number or NaN .
    var num1 = parseFloat(document.getElementById('num1').value);
    var num2 = parseFloat(document.getElementById('num2').value);
    var operator = document.getElementById('operator').value;

    // Perform calculation based on the selected operator
    switch (operator) {
        case '+':
            document.getElementById('result').value = num1 + num2;
            break;
        case '-':
            document.getElementById('result').value = num1 - num2;
            break;
        case '*':
            document.getElementById('result').value = num1 * num2;
            break;
        case '/':
            // Check for division by zero
            if (num2 !== 0) {
                document.getElementById('result').value = num1 / num2;
            } else {
                alert("Cannot divide by zero!");
            }
            break;
        default:
            alert("Invalid operator");
    }
}