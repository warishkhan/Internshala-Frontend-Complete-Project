********************************************* Summery of my project *********************************************************************

batch :- 1st November 2023

Name :- Warish khan

Assignment_4_Internshala-JAVASCRIPT

I created this Calculator website using Html, bootstrap and javascript.The JavaScript Calculator is a simple web application that allows users to perform basic arithmetic calculations. It is designed with a user-friendly interface and uses Bootstrap for styling and JavaScript for dynamic functionality. How I created this website I mention it in code of this website using comments and Its Thought note.

******************************************************Features***************************************************************************
Addition, subtraction, multiplication, and division operations.
Responsive design powered by Bootstrap.
Real-time result updates.
Input validation for numerical values.
Clear and intuitive user interface.

<----Usage---->
The calculator is designed to be used in web browsers, providing users with a convenient tool for quick calculations.

<==========Dependencies==========>
Bootstrap CSS (version 5.3.2)
Bootstrap JS (version 5.3.2)
jQuery (version included with Bootstrap 5.3.2)

Installation :->
Include the necessary dependencies in your HTML file:

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<!-- jQuery (included with Bootstrap) -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRqYYnpeyoFVfAfnE6P" crossorigin="anonymous"></script>

    *         *         *         *          *            How to Use          *         *            *             *             *       
Create HTML elements for number inputs, operator dropdown, result display, and a calculate button.
Include the Bootstrap JS Calculator script on your page.
Initialize the calculator by calling the Calculate() function.
